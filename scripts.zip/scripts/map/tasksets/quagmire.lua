
AddTaskSet("quagmire_taskset", {
    name = STRINGS.UI.CUSTOMIZATIONSCREEN.TASKSETNAMES.QUAGMIRE,
    location = "quagmire",
    tasks = {
        "Quagmire_KitchenTask",
    },
    valid_start_tasks = {
        "Quagmire_KitchenTask",
    },
	set_pieces = {
	},
})

