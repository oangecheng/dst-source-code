local Shaver = Class(function(self, inst)
    self.inst = inst
end)

--Registered actions in componentactions.lua

return Shaver