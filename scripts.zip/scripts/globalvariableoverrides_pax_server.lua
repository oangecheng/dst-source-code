DISABLE_MOD_WARNING = true
SERVER_TERMINATION_TIMER = 60*60*2 -- 60 sec in min, 60 min in hour, 2 hr timer